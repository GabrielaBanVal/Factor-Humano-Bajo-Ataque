SIMULACIÓN "HACKEANDO AL HUMANO"
=================================

Esta es una página educativa para un taller de concientización sobre QR,
phishing e ingeniería social.

CARACTERÍSTICAS
- No tiene formularios.
- No solicita ni almacena datos personales.
- No captura credenciales, OTP, DNI, tarjetas ni contraseñas.
- Todo el efecto ocurre dentro del navegador.

PASO 1
Abre index.html en un navegador para probarla.

PASO 2
Para que funcione al escanear un QR desde celulares, debes publicar
index.html en un servicio de alojamiento web autorizado por tu organización.

PASO 3
Cuando tengas la URL pública (por ejemplo:
https://tu-dominio.com/simulacion), úsala como destino del código QR.

PASO 4
Prueba el QR con un celular antes de usarlo en el taller.

IMPORTANTE
Usa únicamente una URL/dominio autorizado por tu organización y deja
claramente establecido durante el taller que se trata de una simulación.
